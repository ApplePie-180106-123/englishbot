export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'linguabot_access_token',
  USER_DATA: 'linguabot_user_data',
  THEME: 'linguabot_theme',
};